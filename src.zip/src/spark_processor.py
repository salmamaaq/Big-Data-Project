# src/spark_processor.py
import findspark
findspark.init()  # Add this line to initialize PySpark

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, udf
from pyspark.sql.types import StringType, StructType, StructField

import os
import sys
import json
from datetime import datetime


# Add the project root to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import utility functions
from src.utils import preprocess_text, load_models, predict_sentiment

# Define schema for JSON parsing
schema = StructType([
    StructField("reviewerID", StringType()),
    StructField("asin", StringType()),
    StructField("reviewText", StringType()),
    StructField("overall", StringType()),
    StructField("sentiment", StringType()),
    StructField("processed_at", StringType()),
    StructField("reviewTime", StringType()) 
    
])

def main():
    print("Initializing Spark session...")
    
    import os
    jars_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "jars"))
    
    jar_files = []
    for file in os.listdir(jars_dir):
        if file.endswith(".jar"):
            jar_files.append(os.path.join(jars_dir, file))
    
    # Join all JAR paths with commas
    jars_path = ",".join(jar_files)
    
    # Print the path to verify it's correct
    print(f"Using JAR files: {jars_path}")
    
    spark = SparkSession.builder \
        .appName("AmazonReviewsProcessor") \
        .config("spark.jars", jars_path) \
        .master("local[*]") \
        .getOrCreate()

    
    try:
        vectorizer, label_encoder, model = load_models()
        print("Sentiment analysis models loaded successfully")
        
        # Create UDF for sentiment prediction
        def predict_sentiment_udf(text):
            if text:
                return predict_sentiment(text, vectorizer, model, label_encoder)
            return "unknown"
        
        sentiment_udf = udf(predict_sentiment_udf, StringType())
        
    except Exception as e:
        print(f"Error loading sentiment models: {e}")
        sentiment_udf = udf(lambda x: "unknown", StringType())
        
        
    print("Reading from Kafka topic 'amazon-reviews'...")
    df = spark.readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "localhost:9093") \
        .option("subscribe", "amazon-reviews") \
        .load()
    # Process data
    parsed_df = df.selectExpr("CAST(value AS STRING)") \
        .select(from_json(col("value"), schema).alias("data")) \
        .select("data.*")
        
    # Add sentiment prediction
    enriched_df = parsed_df \
        .withColumn("sentiment", sentiment_udf(col("reviewText"))) \
        .withColumn("prediction_time", col("processed_at"))
    
    # Instead of writing directly to MongoDB, use foreachBatch to write in batches
    
    print("Writing processed data to MongoDB...")
    
    def process_batch(batch_df, batch_id):
        # Skip empty batches
        if not batch_df.isEmpty():
            print(f"Processing batch {batch_id} with {batch_df.count()} records")
            
            # Write the batch to MongoDB
            batch_df.write \
                .format("mongo") \
                .option("uri", "mongodb://admin:admin@localhost:27017") \
                .option("database", "amazon_reviews") \
                .option("collection", "processed_reviews") \
                .mode("append") \
                .save()
            
            print(f"Batch {batch_id} written to MongoDB")
            
            
    query = parsed_df.writeStream \
        .format("mongo") \
        .option("uri", "mongodb://admin:admin@localhost:27017") \
        .option("database", "amazon_reviews") \
        .option("collection", "processed_reviews") \
        .foreachBatch(process_batch) \
        .outputMode("append") \
        .start()
    
    print("Streaming query started. Waiting for termination...")
    query.awaitTermination()

if __name__ == "__main__":
    main()