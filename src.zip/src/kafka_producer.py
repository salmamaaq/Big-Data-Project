# src/kafka_producer.py
from kafka import KafkaProducer
import json
import time
from datetime import datetime
import os

def simulate_streaming():
    # Configuration
    sample_file = os.path.join(os.path.dirname(__file__), '../data/sample_stream.json')
    print(f"Reading sample data from: {sample_file}")
    
    producer = KafkaProducer(
        bootstrap_servers='localhost:9093',
        value_serializer=lambda v: json.dumps(v).encode('utf-8')
    )
    
    # Read sample data
    with open(sample_file, 'r') as f:
        reviews = [json.loads(line) for line in f]
    
    print(f"Starting to stream {len(reviews)} reviews...")
    
    for i, review in enumerate(reviews, 1):
        review['processed_at'] = datetime.now().isoformat()
        
        if 'unixReviewTime' in review and 'reviewTime' not in review:
            review['reviewTime'] = datetime.utcfromtimestamp(int(review['unixReviewTime'])).strftime('%Y-%m-%d')
    
        producer.send('amazon-reviews', review)
        print(f"[{i}/{len(reviews)}] Sent review for product {review['asin']}")
        time.sleep(0.5)  # Simulate real-time
    
    print("Streaming completed")

if __name__ == "__main__":
    simulate_streaming()