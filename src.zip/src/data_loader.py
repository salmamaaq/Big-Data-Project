# src/data_loader.py
import pandas as pd
from pymongo import MongoClient
from tqdm import tqdm
import os

def load_to_mongodb():
    # Configuration
    input_file = os.path.join(os.path.dirname(__file__), '../data/processed_reviews.csv')
    print(f"Loading data from: {input_file}")
    
    client = MongoClient(
    'mongodb://admin:admin@localhost:27017/',
    serverSelectionTimeoutMS=5000,  # 5 second timeout
    socketTimeoutMS=30000,          # 30 second socket timeout
    connectTimeoutMS=30000          # 30 second connection timeout
    )
    db = client['amazon_reviews']
    collection = db['raw_reviews']
    
    # Clear existing data
    print("Clearing existing collection...")
    collection.delete_many({})
    
    # Load and process data
    chunk_size = 10000
    total_rows = sum(1 for _ in open(input_file)) - 1  # Count rows excluding header
    print(f"Processing {total_rows} rows in chunks of {chunk_size}...")
    
    for chunk in tqdm(pd.read_csv(input_file, chunksize=chunk_size), total=total_rows//chunk_size+1):
        records = chunk.to_dict('records')
        collection.insert_many(records)
    
    print(f"Successfully loaded {collection.count_documents({})} records")

if __name__ == "__main__":
    load_to_mongodb()