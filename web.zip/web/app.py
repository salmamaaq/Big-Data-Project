from flask import Flask, render_template
from pymongo import MongoClient
from collections import Counter

app = Flask(__name__)

# Connexion MongoDB
client = MongoClient("mongodb://admin:admin@localhost:27017")
db = client["amazon_reviews"]
collection = db["processed_reviews"]

@app.route("/")
def dashboard():
    # Récupérer les derniers avis
    recent_reviews = list(collection.find().sort("processed_at", -1).limit(10))

    # Compter les sentiments
    sentiment_counts = Counter([r["sentiment"] for r in collection.find({}, {"sentiment": 1})])

    # Moyenne de score par produit
    asin_scores = {}
    for doc in collection.find():
        asin = doc.get("asin")
        score = float(doc.get("overall", 0))
        if asin in asin_scores:
            asin_scores[asin]["total"] += score
            asin_scores[asin]["count"] += 1
        else:
            asin_scores[asin] = {"total": score, "count": 1}
    avg_scores = {k: round(v["total"]/v["count"], 2) for k, v in asin_scores.items()}

    return render_template("dashboard.html",
                           recent_reviews=recent_reviews,
                           sentiment_counts=sentiment_counts,
                           avg_scores=avg_scores)


@app.route("/charts")
def charts():
    from datetime import datetime
    import pandas as pd

    # Récupérer les données nécessaires depuis MongoDB
    data = list(collection.find({}, {"sentiment": 1, "reviewTime": 1, "asin": 1}))

    # Convertir en DataFrame
    df = pd.DataFrame(data)
    df["reviewTime"] = pd.to_datetime(df["reviewTime"], errors='coerce')
    df = df.dropna(subset=["reviewTime"])
    df["month"] = df["reviewTime"].dt.strftime('%Y-%m')  # ⬅ utiliser la date réelle

    # 🔍 Sélectionner les 5 derniers mois (distincts, triés)
    last_5_months = sorted(df["month"].unique())[-5:]

    # ⬇️ Filtrer le DataFrame sur ces 5 mois
    df = df[df["month"].isin(last_5_months)]

    # Grouper par mois et sentiment
    grouped = df.groupby(["month", "sentiment"]).size().unstack(fill_value=0).sort_index()

    # Pour le camembert d’un produit précis
    asin_code = "B0002CZUUG"
    product_df = df[df["asin"] == asin_code]
    sentiment_counts = product_df["sentiment"].value_counts().to_dict()

    # Rendre les data JSON pour JS
    return render_template("charts.html",
                           grouped=grouped.to_dict(orient="index"),
                           asin=asin_code,
                           sentiment_counts=sentiment_counts)


if __name__ == "__main__":
    app.run(debug=True)
